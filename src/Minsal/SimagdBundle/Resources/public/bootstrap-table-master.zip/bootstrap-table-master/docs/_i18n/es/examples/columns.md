# Columns []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/columns.md)

---

## Basic columns

Use las opciones `showColumns`, `minimumCountColumns`, y las opciones de columna `visible`, `switchable` para mostrar el menú lisra para mostrar/ocular las columnas. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/24/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## Large columns

Bootstrap table soporta columnas grandes, se mostrará automáticamente el scroll horizontal. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="350" data-src="http://jsfiddle.net/wenyi/e3nk137y/26/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>