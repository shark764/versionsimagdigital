---
layout: default
title: pages.extensions.title
slug: extensions
lead: pages.extensions.lead
---

{% tf extensions/cookie.md %}

{% tf extensions/editable.md %}

{% tf extensions/export.md %}

{% tf extensions/filter-control.md %}

{% tf extensions/filter.md %}

{% tf extensions/flat-json.md %}

{% tf extensions/key-events.md %}

{% tf extensions/mobile.md %}

{% tf extensions/multiple-sort.md %}

{% tf extensions/natural-sorting.md %}

{% tf extensions/reorder-columns.md %}

{% tf extensions/reorder-rows.md %}

{% tf extensions/resizable.md %}

{% tf extensions/toolbar.md %}
